package com.example.projet_flutter_2024

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
