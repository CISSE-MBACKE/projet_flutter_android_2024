import 'package:flutter/material.dart';
import 'package:projet_flutter_2024/ecran_authentification.dart';
import 'package:projet_flutter_2024/ecran_connexion.dart';
import 'package:projet_flutter_2024/functions.dart';

class EcranBienvenue extends StatefulWidget {
  const EcranBienvenue({super.key});

  @override
  State<EcranBienvenue> createState() => _EcranBienvenueState();
}

class _EcranBienvenueState extends State<EcranBienvenue> {
  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Container(
              height: double.infinity,
              width: double.infinity,
              color: Colors.white,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(top: 40.0),
                    child: Text('Bienvenue ! Sur',
                        style: TextStyle(
                            color: Color.fromARGB(255, 148, 196, 220),
                            fontSize: 32,
                            fontWeight: FontWeight.bold)),
                  ),
                  Container(
                    width: 150,
                    height: 70,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: const Center(
                        child: Text(
                      'logo',
                      style: TextStyle(fontSize: 18),
                    )),
                  ),
                  Container(
                    width: 200,
                    height: 150,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black),
                    ),
                    child: const Center(
                      child: Text(
                        'Slides',
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: screenWidth * 0.8,
                        child: ElevatedButton(
                          onPressed: () {
                            setIsFirstVisitStatus(false);

                            Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => EcranConnexion()));
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Color.fromARGB(255, 148, 196, 220),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 40, vertical: 10),
                          ),
                          child: const Text(
                            'Se connecter',
                            style: TextStyle(color: Colors.white, fontSize: 25),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      SizedBox(
                        width: screenWidth * 0.8,
                        child: ElevatedButton(
                          onPressed: () {
                            setIsFirstVisitStatus(false);

                            Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        EcranAuthentification()));
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Color.fromARGB(255, 148, 196, 220),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 10),
                          ),
                          child: const Text(
                            "S'inscrire",
                            style: TextStyle(color: Colors.white, fontSize: 25),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // Positioned(
            //   bottom: 10,
            //   right: 10,
            //   child: Text(
            //     'En savoir plus sur l\'appli',
            //     style: TextStyle(
            //       color: Colors.red,
            //       fontSize: 16,
            //       decoration: TextDecoration.underline,
            //     ),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}
