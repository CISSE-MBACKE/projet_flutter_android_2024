import 'package:flutter/material.dart';
import 'package:projet_flutter_2024/ecran_faire_alerte.dart';

class EcranCarte extends StatefulWidget {
  const EcranCarte({super.key});

  @override
  State<EcranCarte> createState() => _EcranCarteState();
}

class _EcranCarteState extends State<EcranCarte> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(
                Icons.info,
                color: Color.fromARGB(255, 148, 196, 220),
                size: 35,
              ),
              SizedBox(
                width: 10,
              ),
              Text(
                "Carte indisponible pour le moment.\nVeuillez réessayer plus tard.",
                style: TextStyle(
                    color: Color.fromARGB(255, 148, 196, 220), fontSize: 15),
              )
            ],
          ),
        ),
        Positioned(
          // top: ,
          bottom: 25,
          // left: ,
          right: 10,
          child: FloatingActionButton.extended(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => EcranFaireAlerte(),
                ),
              );
            },
            icon: Icon(
              Icons.flood,
              size: 30,
            ),
            label: Text(
              "Faire une alerte",
              style: TextStyle(fontSize: 15),
            ),
            backgroundColor: Colors.red.shade500,
            foregroundColor: Colors.white,
          ),
        ),
      ],
    );
  }
}
