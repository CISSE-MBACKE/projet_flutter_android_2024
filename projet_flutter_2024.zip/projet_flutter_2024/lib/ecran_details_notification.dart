import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:projet_flutter_2024/ecran_notification.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EcranDetailsNotification extends StatefulWidget {
  final Map<String, dynamic> notification;

  const EcranDetailsNotification({super.key, required this.notification});

  @override
  State<EcranDetailsNotification> createState() =>
      _EcranDetailsNotificationState();
}

class _EcranDetailsNotificationState extends State<EcranDetailsNotification> {
  late Map<String, dynamic> notification;
  late bool isRead;
  @override
  void initState() {
    super.initState();

    notification = widget.notification;
    isRead = notification['isRead'];

    if (notification['isRead'] == false) {
      Future.delayed(Duration(milliseconds: 100), () async {
        await markAsRead();
      });
    }
  }

  Future<void> markAsRead() async {
    User? user = FirebaseAuth.instance.currentUser;

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user!.uid)
          .collection('notifications')
          .doc(notification['id'])
          .update({'isRead': true});

      final prefs = await SharedPreferences.getInstance();
      String notificationsJson = prefs.getString('notifications') ?? '[]';
      List<Map<String, dynamic>> notifications =
          List<Map<String, dynamic>>.from(jsonDecode(notificationsJson));

      for (int i = 0; i < notifications.length; i++) {
        if (notifications[i]['id'] == notification['id']) {
          notifications[i]['isRead'] = true;
          break;
        }
      }

      await prefs.setString('notifications', jsonEncode(notifications));

      setState(() {
        notification['isRead'] = true;
      });
    } catch (e) {
      //erreur
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(
              Icons.chevron_left,
              size: 40,
              color: Color.fromARGB(255, 148, 196, 220),
            ),
            onPressed: () {
              if (Navigator.canPop(context)) {
                Navigator.pop(context, !isRead);
              } else {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => EcranNotification()));
              }
            },
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                child: Text.rich(TextSpan(
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                      color: Color.fromARGB(255, 148, 196, 220),
                    ),
                    children: <TextSpan>[
                      TextSpan(
                        text: "Alerte inondation à ",
                      ),
                      TextSpan(
                        text: notification['quartier'],
                      ),
                      TextSpan(
                        text: "!",
                      ),
                    ])),
              ),
              SizedBox(
                height: 10,
              ),
              SizedBox(
                child: Text.rich(
                  TextSpan(style: TextStyle(fontSize: 15), children: <TextSpan>[
                    TextSpan(
                      text: "Une inondation de niveau ",
                    ),
                    TextSpan(
                      text: notification['niveau'],
                    ),
                    TextSpan(
                      text: " a été signalée à ",
                    ),
                    TextSpan(
                      text: notification['region'],
                    ),
                    TextSpan(
                      text: ', ',
                    ),
                    TextSpan(
                      text: notification['quartier'],
                    ),
                    TextSpan(
                      text: " le ",
                    ),
                    TextSpan(
                      text: notification['date_reception']['date'],
                    ),
                    TextSpan(
                      text: " à ",
                    ),
                    TextSpan(
                      text: notification['date_reception']['time'],
                    ),
                  ]),
                ),
              ),
              SizedBox(
                child: Text.rich(TextSpan(
                    style: TextStyle(fontSize: 15),
                    children: <TextSpan>[
                      TextSpan(
                          text: "Type: ",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color.fromARGB(255, 148, 196, 220),
                          )),
                      TextSpan(text: notification['type'])
                    ])),
              ),
              SizedBox(
                child: Text.rich(TextSpan(
                    style: TextStyle(fontSize: 15),
                    children: <TextSpan>[
                      TextSpan(
                          text: "Impact: ",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color.fromARGB(255, 148, 196, 220),
                          )),
                      TextSpan(text: notification['impact'])
                    ])),
              ),
              SizedBox(
                child: Text.rich(TextSpan(
                    style: TextStyle(fontSize: 15),
                    children: <TextSpan>[
                      TextSpan(
                          text: "Recommandation: ",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color.fromARGB(255, 148, 196, 220),
                          )),
                      TextSpan(text: notification['recommandation'])
                    ])),
              ),
              SizedBox(
                height: 20,
              ),
              SizedBox(
                height: 40,
                child: ElevatedButton.icon(
                  label: Text(
                    "Voir sur la carte",
                    style: TextStyle(
                        color: Color.fromARGB(255, 148, 196, 220),
                        fontWeight: FontWeight.bold,
                        fontSize: 20),
                  ),
                  icon: Icon(
                    Icons.map,
                    color: Color.fromARGB(255, 148, 196, 220),
                    size: 20,
                  ),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(
                        color: Color.fromARGB(255, 148, 196, 220),
                        width: 1.0,
                      ),
                    ),
                    backgroundColor: Color.fromARGB(255, 255, 255, 255),
                  ),
                  onPressed: () {},
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
