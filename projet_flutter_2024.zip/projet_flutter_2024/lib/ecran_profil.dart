import 'package:flutter/material.dart';

import 'functions.dart';

class EcranProfil extends StatefulWidget {
  const EcranProfil({super.key});

  @override
  State<EcranProfil> createState() => _EcranProfilState();
}

class _EcranProfilState extends State<EcranProfil> {
  String? nom1, nom2, prenom1, prenom2, localite1, localite2, email1, email2;

  @override
  void initState() {
    super.initState();
    _updateInfo();
  }

  Future<void> _updateInfo() async {
    prenom1 = await getPrenom();
    nom1 = await getNom();
    localite1 = await getLocalite();
    email1 = await getEmail();
    setState(() {
      prenom2 = prenom1;
      nom2 = nom1;
      localite2 = localite1;
      email2 = email1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned(
          top: 0,
          right: 0,
          child: IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.edit,
              size: 30,
              color: Color.fromARGB(255, 148, 196, 220),
            ),
            tooltip: 'Modifier',
          ),
        ),
        Positioned(
          top: MediaQuery.of(context).size.height * 0.17,
          left: 0,
          right: 0,
          bottom: 0,
          child: Container(
            decoration: const BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40),
                  topRight: Radius.circular(40),
                ),
                color: Color.fromARGB(255, 148, 196, 220)),
          ),
        ),
        Positioned(
          top: MediaQuery.of(context).size.height * 0.1,
          left: MediaQuery.of(context).size.width / 2 - 60,
          child: CircleAvatar(
            radius: 65, // Taille du cercle
            backgroundColor: Color.fromARGB(255, 148, 196, 220),
            child: CircleAvatar(
              radius: 60, // Taille interne (blanc)
              backgroundColor: Colors.white,
              child: Icon(
                Icons.person,
                size: 100,
                color: Color.fromARGB(255, 148, 196, 220),
              ),
            ),
          ),
        ),
        Positioned(
          top: MediaQuery.of(context).size.height *
              0.30, // Position en dessous du cercle
          left: 0,
          right: 0,
          child: Center(
            child: Text(
              "$prenom2 $nom2",
              style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
        Positioned(
          top: MediaQuery.of(context).size.height * 0.40,
          left: MediaQuery.of(context).size.width * 0.01,
          right: MediaQuery.of(context).size.width * 0.01,
          child: Column(
            // crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.07,
                width: MediaQuery.of(context).size.width * 0.9,
                padding:
                    const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: const Color.fromARGB(51, 215, 242, 255),
                ),
                child: Text.rich(TextSpan(children: <TextSpan>[
                  TextSpan(
                    text: "Email:",
                    style: TextStyle(
                        color: Colors.white,
                        decoration: TextDecoration.underline,
                        decorationColor: Colors.white),
                  ),
                  TextSpan(
                    text: " ",
                  ),
                  TextSpan(
                    text: email2,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  )
                ])),
              ),
              const SizedBox(height: 20),
              Container(
                height: MediaQuery.of(context).size.height * 0.07,
                width: MediaQuery.of(context).size.width * 0.9,
                padding:
                    const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: const Color.fromARGB(51, 215, 242, 255),
                ),
                child: Text.rich(TextSpan(children: <TextSpan>[
                  TextSpan(
                    text: "Localité:",
                    style: TextStyle(
                        color: Colors.white,
                        decoration: TextDecoration.underline,
                        decorationColor: Colors.white),
                  ),
                  TextSpan(
                    text: " ",
                  ),
                  TextSpan(
                    text: localite2,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  )
                ])),
              ),
            ],
          ),
        ),
        Positioned(
          bottom: MediaQuery.of(context).size.height * 0.03,
          left: 0,
          right: 0,
          child: Align(
            alignment: Alignment.center,
            child: ElevatedButton.icon(
              onPressed: () async {
                await signOut();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(0, 0, 0, 0),
                padding: EdgeInsets.only(
                  top: 10,
                  bottom: 10,
                  left: 20,
                  right: 20,
                ),
                elevation: 0.01,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
              icon: Image.asset(
                "lib/images/logout_icon.PNG",
                width: 20,
                //height: 41.85,
                color: Colors.white,
              ),
              label: Text(
                'Se déconnecter',
                style: TextStyle(
                    fontSize: 20,
                    color: Color.fromARGB(255, 255, 255, 255),
                    fontWeight: FontWeight.normal),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
