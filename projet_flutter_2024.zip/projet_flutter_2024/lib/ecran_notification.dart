import 'package:flutter/material.dart';
import 'package:projet_flutter_2024/ecran_details_notification.dart';

import 'functions.dart';

class EcranNotification extends StatefulWidget {
  const EcranNotification({super.key});

  @override
  State<EcranNotification> createState() => _EcranNotificationState();
}

class _EcranNotificationState extends State<EcranNotification> {
  bool _all = true;

  List<Map<String, dynamic>>? allNotifications;
  List<Map<String, dynamic>>? displayedNotifications;
  List<Map<String, dynamic>>? unreadNotifications;

  @override
  void initState() {
    super.initState();
    _updateNotificationList();
  }

  Future<void> _updateNotificationList() async {
    allNotifications = await getNotificationsFromLocalStorage();
    setState(() {
      displayedNotifications = allNotifications;

      if (allNotifications != null) {
        unreadNotifications = allNotifications!
            .where((notification) => notification['isRead'] == false)
            .toList();
      }
    });
  }

  bool isNoNotification() {
    if (allNotifications == null) {
      return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Stack(
      fit: StackFit.expand,
      clipBehavior: Clip.none,
      children: [
        Positioned(
          top: 0,
          left: 0,
          bottom: screenHeight * 0.75,
          right: 0,
          child: Container(
            decoration: BoxDecoration(
                color: Color.fromARGB(56, 255, 255, 255),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(40),
                  bottomRight: Radius.circular(40),
                )),
            child: SizedBox(
              width: screenWidth * 0.7,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(40),
                        side: _all
                            ? BorderSide(
                                color: Colors.white,
                              )
                            : BorderSide.none,
                      ),
                      backgroundColor: _all
                          ? Color.fromARGB(255, 148, 196, 220)
                          : Color.fromARGB(30, 255, 255, 255),
                    ),
                    onPressed: () {
                      setState(() {
                        _all = true;
                        displayedNotifications = allNotifications;
                      });
                    },
                    child: Text(
                      "Tous",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(40),
                        side: _all
                            ? BorderSide.none
                            : BorderSide(color: Colors.white),
                      ),
                      backgroundColor: _all
                          ? Color.fromARGB(30, 255, 255, 255)
                          : Color.fromARGB(255, 148, 196, 220),
                    ),
                    onPressed: () {
                      setState(() {
                        _all = false;
                        displayedNotifications = unreadNotifications;
                      });
                    },
                    child: Text(
                      "Non Lues",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        //on doit recuperer les messages via la base et le stocker sur une liste et après on fait un ListView.builder qui entre dans une boucle pour afficher les message dans une ListTile
        //on peut mettre tout ça dans une fonction
        //pour l'instant on donne seulement un modele ListTile
        Positioned(
          top: screenHeight * 0.12,
          left: 0,
          bottom: 0,
          right: 0,
          child: displayedNotifications == null
              ? SizedBox(
                  // width: screenWidth * 0.9,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.info,
                        color: Colors.white,
                        size: 25,
                      ),
                      Text(
                        "Aucune notification",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                )
              : ListView.separated(
                  itemCount: displayedNotifications!.length,
                  itemBuilder: (context, index) {
                    final notification = displayedNotifications![index];
                    return ListTile(
                      onTap: () async {
                        final selectedNotication = notification;
                        final shouldRefresh = await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => EcranDetailsNotification(
                                    notification: selectedNotication)));
                        if (shouldRefresh == true) {
                          setState(() async {
                            print(
                                "\n-----------------------------------------------------------------ici\n");
                            await _updateNotificationList();
                          });
                        }
                      },
                      title: Text.rich(
                        TextSpan(
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                          children: <TextSpan>[
                            TextSpan(
                              text: "inondation à ",
                            ),
                            TextSpan(
                              text: notification['region'],
                            ),
                            TextSpan(
                              text: ", ",
                            ),
                            TextSpan(
                              text: notification['quartier'],
                            ),
                          ],
                        ),
                      ),
                      subtitle: Text.rich(
                        TextSpan(
                          style: TextStyle(color: Colors.white, fontSize: 15),
                          children: <TextSpan>[
                            TextSpan(
                              text: "Niveau ",
                            ),
                            TextSpan(
                              text: notification['niveau'],
                            ),
                            TextSpan(
                              text: "\n",
                            ),
                            TextSpan(
                              text: notification['impact'],
                            ),
                          ],
                        ),
                      ),
                      trailing: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            notification['date_reception']['date'],
                            style: TextStyle(color: Colors.black, fontSize: 12),
                          ),
                          notification['isRead']
                              ? Text(" ")
                              : Icon(
                                  Icons.circle,
                                  size: 15,
                                  color: Colors.white,
                                ),
                        ],
                      ),
                    );
                  },
                  separatorBuilder: (context, index) => Divider(
                    color: Colors.black12,
                  ),
                ),
        ),
      ],
    );
  }
}
