import 'package:flutter/material.dart';
import 'package:projet_flutter_2024/ecran_carte.dart';
import 'package:projet_flutter_2024/ecran_conseils.dart';
import 'package:projet_flutter_2024/ecran_notification.dart';
import 'package:projet_flutter_2024/ecran_profil.dart';

import 'functions.dart';

class EcranHomePage extends StatefulWidget {
  const EcranHomePage({super.key});

  @override
  State<EcranHomePage> createState() => _EcranHomePageState();
}

class _EcranHomePageState extends State<EcranHomePage> {
  int _currentIndex = 1;

  final List<Color> _listeBackgroudColor = [
    Colors.white,
    Colors.white,
    Color.fromARGB(255, 148, 196, 220),
  ];

  final List<String> _listeTextHeader = [
    "Profil",
    "Inond_Alerte",
    "Notifications",
  ];

  final List<Widget> _listeEcran = [
    EcranProfil(),
    EcranCarte(),
    EcranNotification(),
  ];

  String? nom1, nom2, prenom1, prenom2;

  Future<void> _updateInfo() async {
    prenom1 = await getPrenom();
    nom1 = await getNom();
    setState(() {
      prenom2 = prenom1;
      nom2 = nom1;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _updateInfo();

    // FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    //   if (message.notification != null) {
    //     print("Notification: ${message.notification!.title}");
    //     print("Message: ${message.notification!.body}");
    //   }

    //   if (message.data.isNotEmpty) {
    //     print("Données supplémentaires reçues : ${message.data}");
    //     // Traitez les données ici, par exemple pour afficher des détails d'alerte
    //   }
    //   // Affichez une alerte ou une notification dans l'application
    // });

    // FirebaseMessaging.onMessageOpenedApp.listen(
    //   (RemoteMessage message) {
    //     if (message.notification != null) {
    //       print("Notification: ${message.notification!.title}");
    //       print("Message: ${message.notification!.body}");
    //     }

    //     if (message.data.isNotEmpty) {
    //       print("Données supplémentaires reçues : ${message.data}");
    //       // Traitez les données ici, par exemple pour afficher des détails d'alerte
    //     }
    //   },
    // );

    
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        key: _scaffoldKey,
        backgroundColor: _listeBackgroudColor[_currentIndex],
        appBar: AppBar(
          centerTitle: true,
          title: Text(_listeTextHeader[_currentIndex]),
          titleTextStyle: TextStyle(
            fontWeight: FontWeight.bold,
            color: Color.fromARGB(255, 44, 139, 255),
            fontSize: 20,
          ),
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          leading: Builder(
            builder: (context) => IconButton(
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
              icon: Icon(Icons.menu),
              iconSize: 30,
              color: Color.fromARGB(255, 44, 139, 255),
            ),
          ),
          elevation: 0.6,
        ),
        drawer: Drawer(
          child: Container(
            decoration: BoxDecoration(
              color: Color.fromARGB(
                  255, 148, 196, 220), // Changer la couleur de fond du Drawer
              border: Border.all(
                color: Colors.white, // Couleur de la bordure
                width: 2, // Épaisseur de la bordure
              ),
            ),
            child: Column(
              children: <Widget>[
                DrawerHeader(
                  decoration: BoxDecoration(
                    color: Colors.white,
                  ),
                  child: Text(
                    "                              INOND_ALERTE                                       ",
                    style: TextStyle(
                        color: Color.fromARGB(255, 148, 196, 220),
                        fontSize: 20),
                  ),
                ),
                // Divider(
                //   color: Colors.white,
                // ),
                ListTile(
                  leading: Icon(
                    Icons.account_circle,
                    size: 30,
                    color: Colors.white,
                  ),
                  title: Text(
                    "$prenom2 $nom2",
                    style: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                  onTap: () {
                    _scaffoldKey.currentState?.closeDrawer();
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => EcranHomePage()),
                    );
                  },
                ),
                Divider(
                  color: Colors.white,
                ),
                ListTile(
                  leading: Icon(
                    Icons.security,
                    size: 30,
                    color: Colors.white,
                  ),
                  title: Text(
                    "Conseils en cas d'innondation",
                    style: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => EcranConseils()));
                  },
                ),
                Divider(
                  color: Colors.white,
                ),
                ListTile(
                  leading: Icon(
                    Icons.help,
                    size: 30,
                    color: Colors.white,
                  ),
                  title: Text(
                    "A propos",
                    style: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                  onTap: () {},
                ),
                Divider(
                  color: Colors.white,
                ),
                Expanded(
                  child: Container(),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                    height: 50,
                    child: ElevatedButton.icon(
                      onPressed: () async {
                        await signOut();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromARGB(0, 0, 0, 0),
                        padding: EdgeInsets.only(
                          top: 10,
                          bottom: 10,
                          left: 20,
                          right: 20,
                        ),
                        elevation: 0.01,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(40),
                        ),
                      ),
                      icon: Image.asset(
                        "lib/images/logout_icon.PNG",
                        width: 20,
                        //height: 41.85,
                        color: Colors.white,
                      ),
                      label: Text(
                        'Se déconnecter',
                        style: TextStyle(
                            fontSize: 20,
                            color: Color.fromARGB(255, 255, 255, 255),
                            fontWeight: FontWeight.normal),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        body: _listeEcran[_currentIndex],
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (int index) {
            setState(() {
              _currentIndex = index;
            });
          },
          type: BottomNavigationBarType.shifting,
          items: [
            BottomNavigationBarItem(
              icon: Image.asset(
                'lib/images/user_icon.png',
                width: 28,
                height: 31.10947368,
              ),
              label: "profil",
              // backgroundColor: Colors.grey,
            ),
            BottomNavigationBarItem(
              icon: Image.asset(
                'lib/images/zone_alert_flood_icon.png',
                width: 28,
                height: 37.471,
              ),
              label: "carte",
              // backgroundColor: Colors.grey,
            ),
            BottomNavigationBarItem(
              icon: Image.asset(
                'lib/images/notification_icon.png',
                width: 30,
                height: 30.6,
              ),
              label: "notification",
              // backgroundColor: Colors.grey,
            ),
          ],
          unselectedItemColor: Color.fromARGB(255, 44, 139, 255),
          selectedItemColor: Color.fromARGB(255, 44, 139, 255),
        ),
      ),
    );
  }
}
