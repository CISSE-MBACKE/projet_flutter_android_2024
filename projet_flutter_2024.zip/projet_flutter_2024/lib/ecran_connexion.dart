import 'package:flutter/material.dart';
import 'package:projet_flutter_2024/ecran_authentification.dart';
import 'package:projet_flutter_2024/main.dart';
import 'functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'gestionnaire_auth.dart';

class EcranConnexion extends StatefulWidget {
  const EcranConnexion({super.key});

  @override
  State<EcranConnexion> createState() => _EcranConnexionState();
}

class _EcranConnexionState extends State<EcranConnexion> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  bool cacherMotDePasse = true;
  bool isConneterPressed = false;
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Stack(
          children: [
            Container(
              padding: const EdgeInsets.all(0),
              margin: const EdgeInsets.only(bottom: 0),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('lib/images/Capture4.PNG'),
                  fit: BoxFit.fill,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 30),
                          child: TextFormField(
                            controller: emailController,
                            keyboardType: TextInputType.emailAddress,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                            ),
                            decoration: InputDecoration(
                              hintText: "Email",
                              hintStyle: TextStyle(
                                  color:
                                      const Color.fromARGB(130, 255, 255, 255),
                                  fontSize: 20),
                              // labelText: "Email",
                              // labelStyle: TextStyle(color: Colors.white),
                              prefixIcon: Icon(
                                Icons.email,
                                size: 20,
                                color: Colors.white,
                              ),
                              enabledBorder: const UnderlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.white, width: 1.0)),
                              focusedBorder: const UnderlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.white, width: 1.0)),
                              errorStyle: TextStyle(color: Colors.red),
                            ),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return "Email requis!";
                              }
                              if (!isValidEmail(value)) {
                                return "Format email incorrect! Format: xyz@txk.xxx";
                              }
                              return null;
                            },
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 30),
                          child: TextFormField(
                            controller: passwordController,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                            ),
                            obscureText: cacherMotDePasse,
                            decoration: InputDecoration(
                              hintText: "Mot de passe",
                              hintStyle: const TextStyle(
                                  color: Color.fromARGB(130, 255, 255, 255),
                                  fontSize: 20),
                              // labelText: "Email",
                              // labelStyle: TextStyle(color: Colors.white),
                              prefixIcon: const Icon(
                                Icons.lock,
                                size: 20,
                                color: Colors.white,
                              ),
                              suffixIcon: IconButton(
                                icon: Icon(
                                  cacherMotDePasse
                                      ? Icons.visibility_off
                                      : Icons.visibility,
                                  color: Colors.white,
                                  size: 20,
                                ),
                                onPressed: () {
                                  setState(() {
                                    cacherMotDePasse = !cacherMotDePasse;
                                  });
                                },
                              ),
                              enabledBorder: const UnderlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.white, width: 1.0)),
                              focusedBorder: const UnderlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.white, width: 1.0)),
                              errorStyle: TextStyle(
                                color: Colors.red,
                              ),
                            ),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return "Mot de passe requis";
                              }
                              if (!isValidPassword(value)) {
                                return "Le mot de passe doit contenir au moins 6 caractères dont une lettre!";
                              }
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(
                          height: 25,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 30),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                margin: const EdgeInsets.all(0),
                                padding: const EdgeInsets.all(0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Color.fromARGB(255, 148, 196, 220),
                                ),
                                child: ElevatedButton(
                                  onPressed: isConneterPressed
                                      ? null
                                      : () async {
                                          if (_formKey.currentState
                                                  ?.validate() ==
                                              true) {
                                            FocusScope.of(context).unfocus();
                                            // Activation du loader
                                            setState(() {
                                              isConneterPressed = true;
                                            });
                                            try {
                                              String email =
                                                  emailController.text.trim();
                                              String password =
                                                  passwordController.text;

                                              // Appel de la méthode asynchrone
                                              User? user =
                                                  await signIn(email, password);

                                              if (user != null) {
                                                await fetchNotificationsFromFirestore(
                                                    user.uid);
                                                await addTokenToFirestore(user);
                                                // Navigation vers la nouvelle page
                                                if (mounted) {
                                                  Navigator.pushReplacement(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) =>
                                                            Gestionnaire()),
                                                  );
                                                }
                                              }
                                            } catch (e) {
                                            } finally {
                                              if (mounted) {
                                                setState(() {
                                                  isConneterPressed = false;
                                                });
                                              }
                                            }
                                          }
                                        },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                  child: isConneterPressed
                                      ? Container(
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          child: CircularProgressIndicator(
                                            color: Color.fromARGB(
                                                255, 148, 196, 220),
                                            backgroundColor: Colors.white,
                                          ),
                                        )
                                      : const Text(
                                          "se connecter",
                                          style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 148, 196, 220),
                                            fontSize: 30,
                                          ),
                                        ),
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              Container(
                                width: 40,
                                height: 43,
                                margin: const EdgeInsets.all(0),
                                padding: const EdgeInsets.all(0),
                                child: ElevatedButton(
                                  onPressed: () {
                                    setState(() {
                                      _formKey.currentState?.validate();
                                    });
                                  },
                                  style: ElevatedButton.styleFrom(
                                    elevation: 0.0,
                                    padding: EdgeInsets.all(0),
                                    backgroundColor: const Color.fromARGB(
                                        255, 179, 215, 233),
                                  ),
                                  child: Image.asset(
                                    'lib/images/Capture1.PNG',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 25,
                        ),
                      ],
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 1,
                        width: 105,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.white60),
                      ),
                      SizedBox(
                        height: 70,
                        width: 120,
                        child: const Text(
                          "ou continuer avec",
                          style: TextStyle(
                              color: Colors.white70,
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                          softWrap: true,
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Container(
                        height: 1,
                        width: 105,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.white60),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 2,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.all(0),
                        padding: EdgeInsets.all(0),
                        height: 60,
                        width: 120,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: ElevatedButton(
                          onPressed: () async {
                            final user = await signInWithGoogle();
                            if (user != null) {
                              Fluttertoast.showToast(
                                  msg:
                                      "Connexion réussie : ${user.displayName}",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: Colors.green,
                                  textColor: Colors.white,
                                  fontSize: 16.0);

                              await fetchNotificationsFromFirestore(user.uid);
                              await addTokenToFirestore(user);

                              GestionnaireAuth();
                            } else {
                              // Échec ou annulation
                              Fluttertoast.showToast(
                                  msg: "Connexion annulée ou échouée",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: Colors.red,
                                  textColor: Colors.white,
                                  fontSize: 16.0);
                            }
                          },
                          style: ElevatedButton.styleFrom(
                              padding: EdgeInsets.all(0),
                              backgroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              )),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Image.asset(
                                'lib/images/google_icon.png',
                                width: 22,
                                height: 22,
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Text(
                                "Google",
                                style: TextStyle(
                                    fontSize: 16, color: Colors.blue.shade700),
                              )
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      Container(
                        margin: EdgeInsets.all(0),
                        padding: EdgeInsets.all(0),
                        height: 60,
                        width: 120,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: ElevatedButton(
                          onPressed: () {},
                          style: ElevatedButton.styleFrom(
                              padding: EdgeInsets.all(0),
                              backgroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              )),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Image.asset(
                                'lib/images/facebook_icon.png',
                                width: 25,
                                height: 25,
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Text(
                                "Facebook",
                                style: TextStyle(
                                    fontSize: 16, color: Colors.blue.shade700),
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: screenHeight * 0.18,
                  )
                ],
              ),
            ),
            Positioned(
              bottom: 0,
              child: Container(
                margin: EdgeInsets.all(0),
                height: screenHeight * 0.11,
                color: Color.fromARGB(255, 148, 196, 220),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Column(
                      children: [
                        Container(
                          margin: EdgeInsets.all(0),
                          width: screenWidth * 0.82,
                          height: screenHeight * 0.05,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Color.fromARGB(255, 148, 196, 220),
                          ),
                          child: Center(
                            child: const Text(
                              "Je n'ai pas de compte?",
                              style: TextStyle(
                                  color: Colors.white60, fontSize: 26),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.all(0),
                          width: screenWidth * 0.87,
                          height: screenHeight * 0.06,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10),
                            ),
                          ),
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          EcranAuthentification()));
                            },
                            child: Text(
                              "s'inscrire",
                              style: TextStyle(
                                fontSize: 30,
                                color: Color.fromARGB(255, 148, 196, 220),
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),
                        ),
                      ],
                    ),
                    Container(
                      margin: EdgeInsets.all(0),
                      width: screenWidth * 0.13,
                      height: screenHeight * 0.11,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                        ),
                      ),
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      EcranAuthentification()));
                        },
                        style: ElevatedButton.styleFrom(
                            elevation: 0.0,
                            backgroundColor: Colors.white,
                            padding: EdgeInsets.only(
                              top: 6,
                              bottom: 6,
                              left: 4,
                            ),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10))),
                        child: Image.asset('lib/images/Capture2.PNG'),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
