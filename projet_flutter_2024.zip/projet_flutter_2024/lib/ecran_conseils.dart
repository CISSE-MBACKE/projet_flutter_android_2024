import 'package:flutter/material.dart';

class EcranConseils extends StatefulWidget {
  const EcranConseils({super.key});

  @override
  State<EcranConseils> createState() => _EcranConseilsState();
}

class _EcranConseilsState extends State<EcranConseils> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Conseils'),
        backgroundColor: Color.fromARGB(255, 148, 196, 220),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          ConseilCard(
            title: 'Avant une inondation',
            description:
                'Identifiez les zones à risque et préparez un kit de survie.',
            icon: Icons.warning_amber_rounded,
          ),
          ConseilCard(
            title: 'Pendant une inondation',
            description:
                'Évacuez immédiatement si vous êtes averti et évitez les zones inondées.',
            icon: Icons.flood,
          ),
          ConseilCard(
            title: 'Après une inondation',
            description:
                'Nettoyez soigneusement pour éviter les infections et contactez les autorités.',
            icon: Icons.cleaning_services,
          ),
        ],
      ),
    );
  }
}

class ConseilCard extends StatelessWidget {
  final String title;
  final String description;
  final IconData icon;

  const ConseilCard(
      {super.key,
      required this.title,
      required this.description,
      required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4.0,
      margin: const EdgeInsets.symmetric(vertical: 10.0),
      child: ListTile(
        leading:
            Icon(icon, color: Color.fromARGB(255, 148, 196, 220), size: 40.0),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(description),
      ),
    );
  }
}
