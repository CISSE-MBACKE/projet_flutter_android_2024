import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NotificationHandler {
  Map<String, dynamic>? notification;
  // Fonction pour stocker la notification dans SharedPreferences et dans FireStore
  Future<Map<String, dynamic>?> saveNotificationToSharedPrefsAndFirestore(
      Map<String, dynamic> data) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    DateTime dateTime;
    if (data['date_reception'] is String) {
      dateTime = DateTime.parse(data['date_reception']);
    } else if (data['date_reception'] is Timestamp) {
      dateTime = data['date_reception'].toDate();
    } else {
      throw Exception('Format de date non supporté');
    }

    String date =
        "${dateTime.year}-${dateTime.month.toString().padLeft(2, '0')}-${dateTime.day.toString().padLeft(2, '0')}";
    String time =
        "${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}:${dateTime.second.toString().padLeft(2, '0')}";

    Map<String, dynamic> newNotificationForSharedPreferences = {
      "date_reception": {
        'date': date,
        'time': time,
      },
      "impact": data['impact'],
      "isRead": bool.parse(data['isRead']),
      "niveau": data['niveau'],
      "position_carte": {
        "latitude": data['latitude'],
        "longitude": data['longitude'],
      },
      "quartier": data['quartier'],
      "recommandation": data['recommandation'],
      "region": data['region'],
      "type": data['type'],
    };

    String? existingNotificationsJson = prefs.getString('notifications');
    List<Map<String, dynamic>> notifications = [];

    if (existingNotificationsJson != null) {
      List<dynamic> decodedList = jsonDecode(existingNotificationsJson);
      notifications = decodedList.cast<Map<String, dynamic>>();
    }

    notifications.insert(0, newNotificationForSharedPreferences);

    String updatedNotificationsJson = jsonEncode(notifications);
    await prefs.setString('notifications', updatedNotificationsJson);

    GeoPoint geoPoint = new GeoPoint(double.tryParse(data['latitude'])!,
        double.tryParse(data['longitude'])!);

    Map<String, dynamic> newNotificationForFireStore = {
      "date_reception": Timestamp.fromDate(dateTime),
      "impact": data['impact'],
      "isRead": bool.parse(data['isRead']),
      "niveau": data['niveau'],
      "position_carte": geoPoint,
      "quartier": data['quartier'],
      "recommandation": data['recommandation'],
      "region": data['region'],
      "type": data['type'],
    };
    User? currentUser = FirebaseAuth.instance.currentUser;
    String uid = currentUser!.uid;

    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('notifications')
        .add(newNotificationForFireStore);

    return newNotificationForSharedPreferences;
  }

  void showNotificationDialog(
      BuildContext context, String? title, String? body) {
    if (context.findAncestorWidgetOfExactType<MaterialApp>() == null) {
      print("Erreur : Pas de MaterialApp dans l'arborescence des widgets.");
      return;
    }

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title ?? "Notification"),
          content: Text(body ?? "Aucune information disponible."),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text("OK"),
            ),
          ],
        );
      },
    );
  }
}
