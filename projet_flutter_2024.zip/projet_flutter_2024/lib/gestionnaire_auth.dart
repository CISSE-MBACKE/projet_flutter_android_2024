import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class GestionnaireAuth extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  User? _user;

  // Getter pour accéder à l'utilisateur actuel
  User? get utilisateur => _user;

  // Ecoute en temps réel les changements de statut d'authentification
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Constructeur pour écouter les changements d'authentification et notifier
  GestionnaireAuth() {
    _auth.authStateChanges().listen((user) {
      _user = user;
      notifyListeners(); // Notifie les widgets abonnées aux changements
    });
  }
}
