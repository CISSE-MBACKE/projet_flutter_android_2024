import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:projet_flutter_2024/functions.dart';

class EcranFaireAlerte extends StatefulWidget {
  const EcranFaireAlerte({super.key});

  @override
  State<EcranFaireAlerte> createState() => _EcranFaireAlerteState();
}

class _EcranFaireAlerteState extends State<EcranFaireAlerte> {
  final List<String> regions = [
    'Dakar',
    'Thiès',
    'Diourbel',
    'Louga',
    'Saint-Louis',
    'Ziguinchor',
    'Kaolack',
    'Fatick',
    'Kaffrine',
    'Tambacounda',
    'Kolda',
    'Sédhiou',
    'Matam',
    'Kédougou',
  ];
  final List<Map<String, List<String>>> data = [
    {
      "Dakar": ["Medina", "Plateau", "Hann Maristes", "Pikine"]
    },
    {
      "Thiès": ["Mbour", "Tivaouane", "Khombole", "Ngaye Mekhe"]
    },
    {
      "Saint-Louis": ["Ndar", "Guet Ndar", "Pikine", "Bango"]
    },
    {
      "Kaolack": ["Ndangane", "Kasnack", "Ngane Alassane", "Kahone"]
    },
    {
      "Tambacounda": ["Goudiry", "Bakel", "Dianké Makha", "Koumpentoum"]
    },
    {
      "Ziguinchor": ["Tilène", "Colobane", "Néma", "Djibélor"]
    },
    {
      "Kolda": ["Sinthiang Koundara", "Saré Yoba", "Dabo", "Salikégné"]
    },
    {
      "Matam": ["Ourossogui", "Thilogne", "Kanel", "Sinthiou Bamambé"]
    },
    {
      "Louga": ["Darou Mousty", "Keur Momar Sarr", "Sakal", "Fass Gueule Tapée"]
    },
    {
      "Fatick": ["Foundiougne", "Diakhao", "Toubacouta", "Gossas"]
    },
    {
      "Kédougou": ["Bandafassi", "Salémata", "Dindéfello", "Fongolimbi"]
    },
    {
      "Sédhiou": ["Bounkiling", "Diattacounda", "Karantaba", "Marsassoum"]
    },
    {
      "Diourbel": ["Touba", "Mbacké", "Bambey", "Nguéniène"]
    },
    {
      "Kaffrine": ["Malem Hodar", "Koungheul", "Birkelane", "Mbirekelane"]
    },
  ];

  TextEditingController villeController = TextEditingController();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String? selectedRegion;
  String? selectedType;
  String? selectedNiveau;
  String? selectedImpact;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Alerte Inondation",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 148, 196, 220),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.chevron_left,
            color: Colors.white,
            size: 40,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: Form(
                key: _formKey,
                child: ListView(
                  children: [
                    DropdownButtonFormField<String>(
                      value: selectedRegion,
                      decoration: InputDecoration(
                          labelText: "Région",
                          border: OutlineInputBorder(),
                          errorStyle: TextStyle(color: Colors.red)),
                      items: regions
                          .map<DropdownMenuItem<String>>((String region) {
                        return DropdownMenuItem<String>(
                          value: region,
                          child: Text(region),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedRegion = newValue;
                        });
                      },
                      validator: (value) {
                        if (value == null) {
                          return 'Veuillez sélectionner une région';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 16),

                    // Champ Ville
                    TextFormField(
                      controller: villeController,
                      decoration: InputDecoration(
                        labelText: "Ville",
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Veuillez entrer la ville';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 16),

                    DropdownButtonFormField<String>(
                      decoration: InputDecoration(
                          labelText: "Type",
                          border: OutlineInputBorder(),
                          errorStyle: TextStyle(color: Colors.red)),
                      items: [
                        DropdownMenuItem(
                          value: "Accumulation d'eau due à la pluie",
                          child: Text("pluie"),
                        ),
                        DropdownMenuItem(
                          value: "Débordement de rivière",
                          child: Text("Débordement de rivière"),
                        ),
                        DropdownMenuItem(
                          value: "Ruissellement",
                          child: Text("Ruissellement"),
                        ),
                        DropdownMenuItem(
                          value: "Marée haute",
                          child: Text("Marée haute"),
                        ),
                      ],
                      onChanged: (String? newType) {
                        selectedType = newType;
                      },
                      validator: (value) {
                        if (value == null) {
                          return 'Veuillez sélectionner un type';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 20),
                    DropdownButtonFormField<String>(
                      decoration: InputDecoration(
                          labelText: "Niveau",
                          border: OutlineInputBorder(),
                          errorStyle: TextStyle(color: Colors.red)),
                      items: [
                        DropdownMenuItem(
                          value: "Élevé",
                          child: Text("Élevé"),
                        ),
                        DropdownMenuItem(
                          value: "Modéré",
                          child: Text("Modéré"),
                        ),
                        DropdownMenuItem(
                          value: "Faible",
                          child: Text("Faible"),
                        ),
                      ],
                      onChanged: (String? newNiveau) {
                        selectedNiveau = newNiveau;
                      },
                      validator: (value) {
                        if (value == null) {
                          return 'Veuillez sélectionner un niveau';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 20),
                    DropdownButtonFormField<String>(
                      decoration: InputDecoration(
                          labelText: "Impacts causés",
                          border: OutlineInputBorder(),
                          errorStyle: TextStyle(color: Colors.red)),
                      items: [
                        DropdownMenuItem(
                          value: "Route principale bloquée",
                          child: Text(
                            "Route principale bloquée",
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ),
                        DropdownMenuItem(
                          value: "Routes secondaires inaccessibles",
                          child: Text(
                            "Routes secondaires inaccessibles",
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ),
                        DropdownMenuItem(
                          value: "Habitats touchés",
                          child: Text(
                            "Habitats touchés",
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ),
                        DropdownMenuItem(
                          value: "Route principale bloquée et habitats touchés",
                          child: Text(
                            "Route principale bloquée\net habitats touchés",
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ),
                        DropdownMenuItem(
                          value:
                              "Habitats touchés et routes secondaires inaccessibles",
                          child: Text(
                            "Habitats touchés et routes\nsecondaires inaccessibles",
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        DropdownMenuItem(
                          value: "Routes bloquées",
                          child: Text(
                            "Routes bloquées",
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ),
                        DropdownMenuItem(
                          value: "Routes bloquées et habitats touchés",
                          child: Text(
                            "Routes bloquées et habitats touchés",
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ),
                      ],
                      onChanged: (String? newImpact) {
                        selectedImpact = newImpact;
                      },
                      validator: (value) {
                        if (value == null) {
                          return 'Veuillez sélectionner un impact';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 20),

                    // Bouton de soumission
                    ElevatedButton(
                      onPressed: () async {
                        if (_formKey.currentState?.validate() == true) {
                          List<String> notification = buildNotification(
                              selectedRegion,
                              villeController.text,
                              selectedType,
                              selectedImpact,
                              selectedNiveau);

                          Map<String, dynamic> dataNotification =
                              buildDataNotification(
                                  selectedRegion,
                                  villeController.text,
                                  selectedType,
                                  selectedImpact,
                                  selectedNiveau);
                          User? user = FirebaseAuth.instance.currentUser;

                          List<String> tokens =
                              await getTokensExceptSender(user!.uid);

                          await sendPushNotificationWithData(
                              tokens: tokens,
                              title: notification[0],
                              body: notification[1],
                              data: dataNotification);
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 15),
                        textStyle: TextStyle(fontSize: 16),
                      ),
                      child: Text("Envoyer l'alerte"),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
