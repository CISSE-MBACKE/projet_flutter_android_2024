import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:projet_flutter_2024/ecran_connexion.dart';
import 'package:projet_flutter_2024/functions.dart';
import 'package:projet_flutter_2024/main.dart';

class EcranFinalisation extends StatefulWidget {
  const EcranFinalisation({super.key});

  @override
  State<EcranFinalisation> createState() => _EcranFinalisationState();
}

TextEditingController prenomController = TextEditingController();
TextEditingController nomController = TextEditingController();
TextEditingController localiteController = TextEditingController();

bool isValidatePress = false;

final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

class _EcranFinalisationState extends State<EcranFinalisation> {
  @override
  Widget build(BuildContext context) {
    // double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 148, 196, 220),
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Container(
          decoration: const BoxDecoration(
            color: Color.fromARGB(255, 148, 196, 220),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                height: screenHeight * 0.1,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  "veuiller remplir ces champs afin de faciliter votre identification.",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontStyle: FontStyle.italic,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 179, 215, 233),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextFormField(
                        controller: prenomController,
                        decoration: const InputDecoration(
                          hintText: 'Prénom',
                          hintStyle: TextStyle(color: Colors.white70),
                          enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.white70),
                          ),
                          focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.white),
                          ),
                          errorStyle: TextStyle(
                            color: Colors.black,
                          ),
                        ),
                        style: const TextStyle(color: Colors.white),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return "le prénom est requi";
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 10),
                      TextFormField(
                        controller: nomController,
                        decoration: const InputDecoration(
                          hintText: 'Nom',
                          hintStyle: TextStyle(color: Colors.white70),
                          enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.white70),
                          ),
                          focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.white),
                          ),
                          errorStyle: TextStyle(
                            color: Colors.black,
                          ),
                        ),
                        style: const TextStyle(color: Colors.white),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return "le nom est requi";
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 10),
                      TextFormField(
                        controller: localiteController,
                        decoration: const InputDecoration(
                          hintText: 'Localité',
                          hintStyle: TextStyle(color: Colors.white70),
                          enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.white70),
                          ),
                          focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.white),
                          ),
                          errorStyle: TextStyle(
                            color: Colors.black,
                          ),
                        ),
                        style: const TextStyle(color: Colors.white),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return "veuillez préciser votre localité";
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 20),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: const Color.fromARGB(255, 179, 215, 233),
                        ),
                        child: ElevatedButton(
                          onPressed: isValidatePress
                              ? null
                              : () async {
                                  if (_formKey.currentState?.validate() ==
                                      true) {
                                    try {
                                      FocusScope.of(context).unfocus();
                                      setState(() {
                                        isValidatePress = true;
                                      });
                                      String? token =
                                          await FirebaseMessaging.instance.getToken();
                                        int isAdd = -1;
                                      if(token != null){

                                      isAdd = await addUserToFirestore(
                                          prenom: prenomController.text,
                                          nom: nomController.text,
                                          localite: localiteController.text,
                                          token: token );
                                      }

                                      if (isAdd == 0) {
                                        User? user =
                                            FirebaseAuth.instance.currentUser;

                                        updateUserData(user!);

                                        if (mounted) {
                                          Navigator.pushReplacement(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      Gestionnaire()));
                                        }
                                      } else {
                                        if (isAdd == 1) {
                                          if (mounted) {
                                            Navigator.pushReplacement(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        EcranFinalisation()));
                                          }
                                        } else {
                                          if (mounted) {
                                            Navigator.pushReplacement(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        EcranConnexion()));
                                          }
                                        }
                                      }
                                    } catch (e) {
                                    } finally {
                                      if (mounted) {
                                        setState(() {
                                          isValidatePress = false;
                                        });
                                      }
                                    }
                                  }
                                },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          child: isValidatePress
                              ? CircularProgressIndicator(
                                  color: Color.fromARGB(255, 148, 196, 220),
                                  backgroundColor: Colors.white,
                                )
                              : const Text(
                                  "  valider  ",
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 148, 196, 220),
                                    fontSize: 30,
                                  ),
                                ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
