import 'package:flutter/material.dart';
import 'package:projet_flutter_2024/ecran_connexion.dart';
import 'package:projet_flutter_2024/gestionnaire_auth.dart';
import 'functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';

class EcranAuthentification extends StatefulWidget {
  const EcranAuthentification({super.key});

  @override
  State<EcranAuthentification> createState() => _EcranAuthentificationState();
}

class _EcranAuthentificationState extends State<EcranAuthentification> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  bool cacherMotDePasse = true;
  bool cacherConfirmation = true;
  bool isInscrirePressed = false;
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Container(
          padding: const EdgeInsets.all(0),
          margin: const EdgeInsets.all(0),
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('lib/images/Capture5.PNG'),
              fit: BoxFit.fill,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Icon(
                    Icons.person_add_alt_1_sharp,
                    size: 65,
                    color: Colors.white,
                  ),
                  Text(
                    "Inscription",
                    style: TextStyle(
                      fontSize: 30,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 30),
                          child: TextFormField(
                            controller: emailController,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                            ),
                            decoration: InputDecoration(
                                hintText: "Email",
                                hintStyle: TextStyle(
                                    color: const Color.fromARGB(
                                        130, 255, 255, 255),
                                    fontSize: 20),
                                // labelText: "Email",
                                // labelStyle: TextStyle(color: Colors.white),
                                prefixIcon: Icon(
                                  Icons.email,
                                  size: 20,
                                  color: Colors.white,
                                ),
                                enabledBorder: const UnderlineInputBorder(
                                    borderSide: BorderSide(
                                        color: Colors.white, width: 1.0)),
                                focusedBorder: const UnderlineInputBorder(
                                    borderSide: BorderSide(
                                        color: Colors.white, width: 1.0)),
                                errorStyle: TextStyle(
                                  color: Colors.red,
                                )),
                            keyboardType: TextInputType.emailAddress,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return "Email est requis!";
                              }
                              if (!isValidEmail(value)) {
                                return "Format email incorrect! Format: xyz@txk.xxx";
                              }
                              return null;
                            },
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 30),
                          child: TextFormField(
                            controller: passwordController,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                            ),
                            obscureText: cacherMotDePasse,
                            decoration: InputDecoration(
                                hintText: "Mot de passe",
                                hintStyle: const TextStyle(
                                    color: Color.fromARGB(130, 255, 255, 255),
                                    fontSize: 20),
                                prefixIcon: const Icon(
                                  Icons.lock,
                                  size: 20,
                                  color: Colors.white,
                                ),
                                suffixIcon: IconButton(
                                  onPressed: () {
                                    setState(() {
                                      cacherMotDePasse = !cacherMotDePasse;
                                    });
                                  },
                                  icon: Icon(
                                    cacherMotDePasse
                                        ? Icons.visibility_off
                                        : Icons.visibility,
                                    color: Colors.white,
                                    size: 20,
                                  ),
                                ),
                                enabledBorder: const UnderlineInputBorder(
                                    borderSide: BorderSide(
                                        color: Colors.white, width: 1.0)),
                                focusedBorder: const UnderlineInputBorder(
                                    borderSide: BorderSide(
                                        color: Colors.white, width: 1.0)),
                                errorStyle: TextStyle(color: Colors.red)),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return "le mot de passe est requis";
                              }
                              if (!isValidPassword(value)) {
                                return "Le mot de passe doit contenir au moins 6 caractères dont une lettre!";
                              }
                              return null;
                            },
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 30),
                          child: TextFormField(
                            controller: confirmPasswordController,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                            ),
                            obscureText: cacherConfirmation,
                            decoration: InputDecoration(
                                hintText: "Confirmation",
                                hintStyle: const TextStyle(
                                    color: Color.fromARGB(130, 255, 255, 255),
                                    fontSize: 20),
                                prefixIcon: const Icon(
                                  Icons.lock,
                                  size: 20,
                                  color: Colors.white,
                                ),
                                suffixIcon: IconButton(
                                  icon: Icon(
                                    cacherConfirmation
                                        ? Icons.visibility_off
                                        : Icons.visibility,
                                    color: Colors.white,
                                    size: 20,
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      cacherConfirmation = !cacherConfirmation;
                                    });
                                  },
                                ),
                                enabledBorder: const UnderlineInputBorder(
                                    borderSide: BorderSide(
                                        color: Colors.white, width: 1.0)),
                                focusedBorder: const UnderlineInputBorder(
                                    borderSide: BorderSide(
                                        color: Colors.white, width: 1.0)),
                                errorStyle: TextStyle(color: Colors.black)),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return "Confirmation requise";
                              }
                              if (confirmPasswordController.text !=
                                  passwordController.text) {
                                return "Mot de passe et confirmation différents!";
                              }
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(
                          height: 25,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 30),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                margin: const EdgeInsets.all(0),
                                padding: const EdgeInsets.all(0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color:
                                      const Color.fromARGB(255, 148, 196, 220),
                                ),
                                child: ElevatedButton(
                                  onPressed: () async {
                                    if (_formKey.currentState?.validate() ==
                                        true) {
                                      try {
                                        FocusScope.of(context).unfocus();

                                        setState(() {
                                          isInscrirePressed = true;
                                        });

                                        String email =
                                            emailController.text.trim();
                                        String password =
                                            passwordController.text;
                                        User? user = await createAccount(
                                            email, password);

                                        if (user != null) {
                                          Fluttertoast.showToast(
                                              msg:
                                                  "Compte créé avec succès pour : ${user.email}",
                                              toastLength: Toast.LENGTH_SHORT,
                                              gravity: ToastGravity.BOTTOM,
                                              timeInSecForIosWeb: 1,
                                              backgroundColor: Colors.green,
                                              textColor: Colors.white,
                                              fontSize: 16.0);

                                          if (mounted) {
                                            Navigator.pushReplacement(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        EcranConnexion()));
                                          }
                                        } else {
                                          Fluttertoast.showToast(
                                              msg:
                                                  "La création du compte a échoué.",
                                              toastLength: Toast.LENGTH_SHORT,
                                              gravity: ToastGravity.BOTTOM,
                                              timeInSecForIosWeb: 1,
                                              backgroundColor: Colors.red,
                                              textColor: Colors.white,
                                              fontSize: 16.0);
                                        }
                                      } catch (e) {
                                      } finally {
                                        if (mounted) {
                                          setState(() {
                                            isInscrirePressed = false;
                                          });
                                        }
                                      }
                                    }
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                  child: isInscrirePressed
                                      ? CircularProgressIndicator(
                                          color: Color.fromARGB(
                                              255, 148, 196, 220),
                                          backgroundColor: Colors.white,
                                        )
                                      : const Text(
                                          "  s'inscrire  ",
                                          style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 148, 196, 220),
                                            fontSize: 30,
                                          ),
                                        ),
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              Container(
                                width: 40,
                                height: 43,
                                margin: const EdgeInsets.all(0),
                                padding: const EdgeInsets.all(0),
                                child: ElevatedButton(
                                  onPressed: () {
                                    setState(() {
                                      _formKey.currentState?.validate();
                                    });
                                  },
                                  style: ElevatedButton.styleFrom(
                                    elevation: 0.0,
                                    padding: EdgeInsets.all(0),
                                    backgroundColor: const Color.fromARGB(
                                        255, 148, 196, 220),
                                  ),
                                  child: Image.asset(
                                    'lib/images/Capture1_1.PNG',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  //),
                  const SizedBox(
                    height: 25,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 1,
                        width: 105,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.white60),
                      ),
                      Container(
                        height: 70,
                        width: 120,
                        child: const Text(
                          "ou continuer avec",
                          style: TextStyle(
                              color: Colors.white70,
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                          softWrap: true,
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Container(
                        height: 1,
                        width: 105,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.white60),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 2,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.all(0),
                        padding: EdgeInsets.all(0),
                        height: 60,
                        width: 120,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: ElevatedButton(
                          onPressed: () async {
                            final user = await signInWithGoogle();
                            if (user != null) {
                              Fluttertoast.showToast(
                                  msg:
                                      "Connexion réussie : ${user.displayName}",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: Colors.green,
                                  textColor: Colors.white,
                                  fontSize: 16.0);

                              await fetchNotificationsFromFirestore(user.uid);
                              await addTokenToFirestore(user);

                              GestionnaireAuth();
                            } else {
                              // Échec ou annulation
                              Fluttertoast.showToast(
                                  msg: "Connexion annulée ou échouée",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: Colors.red,
                                  textColor: Colors.white,
                                  fontSize: 16.0);
                            }
                          },
                          style: ElevatedButton.styleFrom(
                              padding: EdgeInsets.all(0),
                              backgroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              )),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Image.asset(
                                'lib/images/google_icon.png',
                                width: 22,
                                height: 22,
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Text(
                                "Google",
                                style: TextStyle(
                                    fontSize: 16, color: Colors.blue.shade700),
                              )
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      Container(
                        margin: EdgeInsets.all(0),
                        padding: EdgeInsets.all(0),
                        height: 60,
                        width: 120,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: ElevatedButton(
                          onPressed: () {},
                          style: ElevatedButton.styleFrom(
                              padding: EdgeInsets.all(0),
                              backgroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              )),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Image.asset(
                                'lib/images/facebook_icon.png',
                                width: 25,
                                height: 25,
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Text(
                                "Facebook",
                                style: TextStyle(
                                    fontSize: 16, color: Colors.blue.shade700),
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: screenHeight * 0.07,
                  )
                ],
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        height: screenHeight * 0.11,
        color: const Color.fromARGB(255, 148, 196, 220),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              margin: EdgeInsets.all(0),
              width: screenWidth,
              height: screenHeight * 0.06,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(10),
                  topRight: Radius.circular(10),
                  bottomLeft: Radius.circular(10),
                ),
              ),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => EcranConnexion()));
                },
                child: Text(
                  "se connecter",
                  style: TextStyle(
                    fontSize: 30,
                    color: const Color.fromARGB(255, 148, 196, 220),
                  ),
                ),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10),
                        bottomLeft: Radius.circular(10),
                      ),
                    )),
              ),
            ),
            Row(
              children: [
                Container(
                  margin: EdgeInsets.all(0),
                  width: screenWidth * 0.80,
                  height: screenHeight * 0.05,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    // color: const Color.fromARGB(255, 224, 0, 0),
                  ),
                  child: Center(
                    child: const Text(
                      "J'ai déjà un compte?",
                      style: TextStyle(color: Colors.white60, fontSize: 26),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.all(0),
                  width: screenWidth * 0.20,
                  height: screenHeight * 0.05,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(10),
                    ),
                  ),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => EcranConnexion()));
                    },
                    style: ElevatedButton.styleFrom(
                        // backgroundColor: Colors.white,
                        elevation: 0.0,
                        padding: EdgeInsets.only(
                          right: 5,
                          bottom: 2,
                          left: 5,
                        ),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10))),
                    child: Image.asset('lib/images/Capture3.PNG'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
