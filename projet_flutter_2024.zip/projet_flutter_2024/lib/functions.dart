import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'dart:convert'; //pour les notifications
import 'package:googleapis_auth/auth_io.dart';
import 'package:flutter/services.dart';

bool isValidEmail(String email) {
  String emailPattern =
      r'^[a-zA-Z0-9]+([._%+-]?[a-zA-Z0-9]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z]{2,})+$';
  RegExp regex = RegExp(emailPattern);
  return regex.hasMatch(email);
}

bool isValidPassword(String password) {
  String passwordPattern = r'^(?=.*[a-zA-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$';
  RegExp regex = RegExp(passwordPattern);
  return regex.hasMatch(password);
}

Future<User?> createAccount(String email, String password) async {
  try {
    UserCredential userCredential = await FirebaseAuth.instance
        .createUserWithEmailAndPassword(email: email, password: password);

    User? user = userCredential.user;
    return user;
  } on FirebaseAuthException catch (e) {
    if (e.code == 'email-already-in-use') {
      print("Un compte existe déjà avec cet email.");
    }

    return null;
  }
}

Future<User?> signInWithGoogle() async {
  try {
    final GoogleSignIn googleSignIn = GoogleSignIn();
    final GoogleSignInAccount? googleUser = await googleSignIn.signIn();

    if (googleUser == null) {
      return null;
    }

    final GoogleSignInAuthentication googleAuth =
        await googleUser.authentication;

    final AuthCredential credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    final UserCredential userCredential =
        await FirebaseAuth.instance.signInWithCredential(credential);

    return userCredential.user;
  } catch (e) {
    Fluttertoast.showToast(
        msg: "Une erreur est survenue",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0);

    return null;
  }
}

Future<User?> signIn(String email, String password) async {
  try {
    UserCredential userCredential =
        await FirebaseAuth.instance.signInWithEmailAndPassword(
      email: email,
      password: password,
    );

    Fluttertoast.showToast(
        msg: "Connexion réussie : ${userCredential.user?.email}",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.green,
        textColor: Colors.white,
        fontSize: 16.0);

    return userCredential.user;
  } on FirebaseAuthException catch (e) {
    String errorMessage;

    if (e.code == 'user-not-found') {
      errorMessage = 'Aucun utilisateur trouvé pour cet email.';
    } else if (e.code == 'wrong-password') {
      errorMessage = 'Mot de passe incorrect.';
    } else {
      errorMessage = 'email ou mot de passe incorrect.';
    }

    Fluttertoast.showToast(
        msg: errorMessage,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0);

    throw Exception(errorMessage);
  } catch (e) {
    Fluttertoast.showToast(
        msg: "Une erreur est survenue",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0);

    throw Exception(e);
  }
}

Future<void> signOut() async {
  try {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool vf = await getIsFirstVisitStatus();
    await prefs.clear();
    prefs.setBool('IsFirstVisit', vf);

    User? user = FirebaseAuth.instance.currentUser;
    await removeTokenToFirestore(user!);
    await FirebaseAuth.instance.signOut();
  } catch (e) {
    Fluttertoast.showToast(
        msg: "erreur de déconnexion reesayez",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 5,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0);
  }
}

///************************************************//

Future<void> setIsFirstVisitStatus(bool isFirstVisit) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();

  prefs.setBool('IsFirstVisit', isFirstVisit);
}

Future<bool> getIsFirstVisitStatus() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();

  return prefs.getBool('IsFirstVisit') ?? true;
}

Future<void> setUserData(
    String prenom, String nom, String localite, String email) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();

  prefs.setString('prenom', prenom);
  prefs.setString('nom', nom);
  prefs.setString('localite', localite);
  prefs.setString('email', email);
}

Future<String?> getPrenom() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();

  return prefs.getString('prenom');
}

Future<String?> getNom() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('nom');
}

Future<String?> getLocalite() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('localite');
}

Future<String?> getEmail() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('email');
}

//////*************************************************************************/

Future<int> addUserToFirestore({
  required String prenom,
  required String nom,
  required String localite,
  required String token,
}) async {
  User? currentUser = FirebaseAuth.instance.currentUser;

  if (currentUser != null) {
    String uid = currentUser.uid;

    Map<String, dynamic> userData = {
      "prenom": prenom,
      "nom": nom,
      "localite": localite,
      "date_creation_compte": DateTime.now(),
      "tokens": [token],
    };

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .set(userData);
      Fluttertoast.showToast(
          msg: "Informations ajoutées avec succès",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
      return 0;
    } catch (e) {
      Fluttertoast.showToast(
          msg: "Erreur: veuillez réessayer",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 3,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
      return 1;
    }
  } else {
    Fluttertoast.showToast(
        msg: "Erreur: connectez-vous pour continuer",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0);
    return -1;
  }
}

Future<void> addTokenToFirestore(User user) async {
  String? token = await FirebaseMessaging.instance.getToken();

  if (token != null) {
    await FirebaseFirestore.instance.collection('users').doc(user.uid).update({
      'tokens': FieldValue.arrayUnion([token])
    });
  }
}

Future<void> removeTokenToFirestore(User user) async {
  String? token = await FirebaseMessaging.instance.getToken();

  if (token != null) {
    await FirebaseFirestore.instance.collection('users').doc(user.uid).update({
      'tokens': FieldValue.arrayRemove([token])
    });
  }
}

Future<bool> isUserFinalized(User? user) async {
  String? prenom = await getPrenom();

  if (prenom != null) {
    return true;
  }

  if (user != null) {
    DocumentSnapshot usersData = await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .get();

    if (usersData.exists) {
      String email = user.email!;
      setUserData(usersData['prenom'].toString(), usersData['nom'].toString(),
          usersData['localite'].toString(), email.toString());
      return true;
    }
  }
  return false;
}

Future<void> updateUserData(User user) async {
  DocumentSnapshot userDoc =
      await FirebaseFirestore.instance.collection('users').doc(user.uid).get();

  if (userDoc.exists) {
    Map<String, dynamic> userData = userDoc.data() as Map<String, dynamic>;

    //je doit stocker les donnée localement avec SharedPreferencies ici et une seule fois
    String email = user.email!;

    setUserData(userData['prenom'].toString(), userData['nom'].toString(),
        userData['localite'].toString(), email.toString());
  }
}

///////////////////////////////////////////////Gestion de NOTIFICATION

Future<void> fetchNotificationsFromFirestore(String userId) async {
  final prefs = await SharedPreferences.getInstance();

  try {
    final notificationsSnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection('notifications')
        .orderBy('date_reception', descending: true)
        .limit(15)
        .get();

    if (notificationsSnapshot.docs.isNotEmpty) {
      List<Map<String, dynamic>> notifications =
          notificationsSnapshot.docs.map((doc) {
        Map<String, dynamic> data = doc.data();

        if (data['position_carte'] is GeoPoint) {
          GeoPoint geoPoint = data['position_carte'];
          data['position_carte'] = {
            'latitude': geoPoint.latitude,
            'longitude': geoPoint.longitude,
          };
        }

        if (data['date_reception'] is Timestamp) {
          Timestamp timestamp = data['date_reception'];
          DateTime dateTime = timestamp.toDate();

          String date =
              "${dateTime.year}-${dateTime.month.toString().padLeft(2, '0')}-${dateTime.day.toString().padLeft(2, '0')}";
          String time =
              "${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}:${dateTime.second.toString().padLeft(2, '0')}";

          data['date_reception'] = {'date': date, 'time': time};
        }

        return {'id': doc.id, ...data};
      }).toList();

      await prefs.setString('notifications', jsonEncode(notifications));
    } else {
      print("\n----------------------------NO NOTIF\n");
    }
  } catch (e) {
    print("\n---------------------------------->ERREUR NOTIF: $e");
  }
}

////////////////////////////////////////////////////GESTION DE L'ENVOI DE NOTIFICATIONS

Stream<void> listenForNewNotifications(String userId) async* {
  //cette fonction est à revoir////////////////////////
  final prefs = await SharedPreferences.getInstance();

  FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection('notifications')
      .snapshots()
      .listen((snapshot) async {
    for (var change in snapshot.docChanges) {
      if (change.type == DocumentChangeType.added) {
        // Nouvelle notification détectée
        Map<String, dynamic> newNotification = {
          'id': change.doc.id,
          ...change.doc.data()!,
        };

        String? storedNotifications = prefs.getString('notifications');
        List<Map<String, dynamic>> notifications = storedNotifications != null
            ? List<Map<String, dynamic>>.from(jsonDecode(storedNotifications))
            : [];

        notifications.add(newNotification);

        await prefs.setString('notifications', jsonEncode(notifications));
      }
    }
  });
}

Future<List<Map<String, dynamic>>?> getNotificationsFromLocalStorage() async {
  final prefs = await SharedPreferences.getInstance();

  String? storedNotifications = prefs.getString('notifications');
  if (storedNotifications != null) {
    return List<Map<String, dynamic>>.from(jsonDecode(storedNotifications));
  } else {
    return null;
  }
}

Future<List<String>> getTokensExceptSender(String senderId) async {
  List<String> tokens = [];

  try {
    QuerySnapshot snapshot =
        await FirebaseFirestore.instance.collection('users').get();

    for (var doc in snapshot.docs) {
      if (doc.id != senderId) {
        List<dynamic> userTokens = doc['tokens'];
        tokens.addAll(userTokens.cast<String>());
      }
    }
  } catch (e) {
    //erreur
  }
  return tokens;
}

List<String> buildNotification(String? region, String? ville, String? type,
    String? impact, String? niveau) {
  List<String> notification = [];

  String title = "Une inondation à $region, $ville";

  String body = "Niveau $niveau\n$impact";

  notification.add(title);
  notification.add(body);

  return notification;
}

Map<String, dynamic> buildDataNotification(String? region, String? ville,
    String? type, String? impact, String? niveau) {
  Map<String, dynamic> dataNotification = {
    "date_reception": DateTime.now().toIso8601String(),
    "impact": impact,
    "isRead": 'false', //convertit en chaine mais bool
    "niveau": niveau,
    "latitude": '10', //convertit en chaine
    "longitude": '20', //convertie en chaine
    "quartier": ville,
    "recommandation": "evitez les déplacements dans cette zone",
    "region": region,
    "type": type,
  };

  return dataNotification;
}

Future<void> sendPushNotificationWithData({
  required List<String> tokens,
  required String title,
  required String body,
  required Map<String, dynamic> data,
}) async {
  // Charger le fichier JSON d'authentification
  final jsonString = await rootBundle
      .loadString('lib/services/projetflutter2024-9119b-52100547e9a1.json');
  final serviceAccount = jsonDecode(jsonString);
  final credentials = ServiceAccountCredentials.fromJson(serviceAccount);

  // Créer un client authentifié
  final client = await clientViaServiceAccount(
    credentials,
    ['https://www.googleapis.com/auth/firebase.messaging'],
  );

  // Construire l'URL de l'API
  final url = Uri.parse(
    'https://fcm.googleapis.com/v1/projects/projetflutter2024-9119b/messages:send',
  );

  try {
    // Boucle sur tous les tokens pour envoyer une notification à chaque token
    for (String token in tokens) {
      final message = {
        "message": {
          "token": token, // Envoi à un seul token à la fois
          "notification": {
            "title": title,
            "body": body,
          },
          "data": data,
        }
      };

      // Envoyer la requête pour ce token
      final response = await client.post(
        url,
        headers: {
          "Content-Type": "application/json",
        },
        body: jsonEncode(message),
      );
        
      if (response.statusCode == 200) {
        Fluttertoast.showToast(
            msg: "Alerte envoyé avec succées",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);
      } else {
        Fluttertoast.showToast(
            msg: "Erreur lors de l'envoi de l'alert",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
      }
    }
  } catch (e) {
    Fluttertoast.showToast(
        msg: "Erreur fatale: Echec de l'envoi",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0);
  } finally {
    client.close();
  }
}
