import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:projet_flutter_2024/ecran_connexion.dart';
import 'package:projet_flutter_2024/ecran_details_notification.dart';
import 'package:projet_flutter_2024/ecran_home_page.dart';
import 'package:projet_flutter_2024/functions.dart';
import 'package:projet_flutter_2024/notification_handler.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';

import 'gestionnaire_auth.dart';
import 'package:projet_flutter_2024/ecran_bienvenue.dart';
import 'package:projet_flutter_2024/ecran_finalisation.dart';
// import 'package:flutter_local_notifications/flutter_local_notifications.dart';

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
}


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  FirebaseMessaging messaging = FirebaseMessaging.instance;

  // Demander l'autorisation pour recevoir des notifications
  NotificationSettings settings = await messaging.requestPermission();

  if (settings.authorizationStatus == AuthorizationStatus.authorized) {
    //
  }

  // Enregistrer le gestionnaire d'arrière-plan
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();

    NotificationHandler notificationHandler = new NotificationHandler();

    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {

      if (message.data.isNotEmpty) {
        
        notificationHandler.notification = await notificationHandler
            .saveNotificationToSharedPrefsAndFirestore(message.data);
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) async {
      if (message.data.isNotEmpty) {
        
        notificationHandler.notification = await notificationHandler
            .saveNotificationToSharedPrefsAndFirestore(message.data);
      }

      if (message.notification != null) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => EcranDetailsNotification(
              notification: notificationHandler.notification!,
            ),
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => GestionnaireAuth(),
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Gestionnaire(),
      ),
    );
  }
}

class Gestionnaire extends StatelessWidget {
  const Gestionnaire({super.key});

  @override
  Widget build(BuildContext context) {
    // Récupère l'état utilisateur via StreamProvider
    return Consumer<GestionnaireAuth>(
      builder: (context, gestionnaireAuth, child) {
        final user = gestionnaireAuth.utilisateur;

        return FutureBuilder<List<bool>>(
          // Future.wait pour attendre plusieurs Futures
          future: Future.wait([
            getIsFirstVisitStatus(),
            isUserFinalized(user),
          ]),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(
                  child: CircularProgressIndicator(
                color: Colors.white,
              ));
            } else if (snapshot.hasError) {
              return Center(child: Text("Erreur: ${snapshot.error}"));
            } else {
              final isFirstVisit = snapshot.data![0];
              final isFinalized = snapshot.data![1];

              if (isFirstVisit == true) {
                return EcranBienvenue();
              } else {
                if (user == null) {
                  return EcranConnexion(); //a modifier à EcranConnexion()
                } else {
                  if (isFinalized == false) {
                    return EcranFinalisation();
                  } else {
                    return EcranHomePage();
                  }
                }
              }
            }
          },
        );
      },
    );
  }
}
